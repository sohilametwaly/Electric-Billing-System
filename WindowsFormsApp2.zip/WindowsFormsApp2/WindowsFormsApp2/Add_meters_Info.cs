﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Add_meters_Info : Form
    {
        public Add_meters_Info()
        {
            InitializeComponent();
        }

        private void Add_meters_Info_Load(object sender, EventArgs e)
        {

        }
    }
}
